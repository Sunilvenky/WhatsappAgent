/**
 * Base API configuration and utilities
 */
import axios from 'axios';

// API base URL - uses environment variable or defaults to localhost
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// Create axios instance with default configuration
const api = axios.create({
  baseURL: `${API_BASE_URL}/api/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000, // 30 seconds
});

// Request interceptor to add auth token and tenant ID
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    const tenantId = localStorage.getItem('tenantId');
    
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    if (tenantId) {
      config.headers['X-Tenant-ID'] = tenantId;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle 401 Unauthorized - redirect to login
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    
    // Handle network errors
    if (!error.response) {
      console.error('Network error:', error.message);
      return Promise.reject(new Error('Network error. Please check your connection.'));
    }
    
    // Return error with message
    const message = error.response?.data?.detail || error.message || 'An error occurred';
    return Promise.reject(new Error(message));
  }
);

/**
 * Generic API request helper
 */
export const apiRequest = async (method, url, data = null, config = {}) => {
  try {
    const response = await api({
      method,
      url,
      data,
      ...config,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

/**
 * GET request
 */
export const get = (url, config = {}) => apiRequest('GET', url, null, config);

/**
 * POST request
 */
export const post = (url, data, config = {}) => apiRequest('POST', url, data, config);

/**
 * PUT request
 */
export const put = (url, data, config = {}) => apiRequest('PUT', url, data, config);

/**
 * PATCH request
 */
export const patch = (url, data, config = {}) => apiRequest('PATCH', url, data, config);

/**
 * DELETE request
 */
export const del = (url, config = {}) => apiRequest('DELETE', url, null, config);

/**
 * Admin API Methods - Tenant Management
 */
export const adminAPI = {
  // Tenants
  tenants: {
    create: (data) => post('/tenants/', data),
    getAll: () => get('/tenants/'),
    getById: (id) => get(`/tenants/${id}`),
    update: (id, data) => put(`/tenants/${id}`, data),
    delete: (id) => del(`/tenants/${id}`),
  },

  // Tenant Users
  tenantUsers: {
    getAll: (tenantId) => get(`/tenants/${tenantId}/users`),
    add: (tenantId, data) => post(`/tenants/${tenantId}/users`, data),
    updateRole: (tenantId, userId, data) => put(`/tenants/${tenantId}/users/${userId}`, data),
    remove: (tenantId, userId) => del(`/tenants/${tenantId}/users/${userId}`),
  },

  // API Keys
  apiKeys: {
    create: (tenantId, data) => post(`/tenants/${tenantId}/api-keys`, data),
    getAll: (tenantId) => get(`/tenants/${tenantId}/api-keys`),
    delete: (tenantId, keyId) => del(`/tenants/${tenantId}/api-keys/${keyId}`),
  },

  // Usage & Billing
  billing: {
    getStats: (tenantId) => get(`/tenants/${tenantId}/usage/stats`),
    getInvoices: () => get('/invoices/'),
    getInvoiceById: (id) => get(`/invoices/${id}`),
    createInvoice: (data) => post('/invoices/', data),
    updateInvoice: (id, data) => put(`/invoices/${id}`, data),
    createReminder: (invoiceId, data) => post(`/invoices/${invoiceId}/reminders`, data),
  },

  // OTP
  otp: {
    send: (data) => post('/otp/send', data),
    verify: (data) => post('/otp/verify', data),
  },

  // Orders
  orders: {
    create: (data) => post('/orders/', data),
    getAll: () => get('/orders/'),
    getById: (id) => get(`/orders/${id}`),
    update: (id, data) => put(`/orders/${id}`, data),
    markPacked: (orderId, itemId) => put(`/orders/${orderId}/items/${itemId}/pack`),
  },

  // Campaigns
  campaigns: {
    createStep: (campaignId, data) => post(`/campaigns/${campaignId}/steps`, data),
    getSteps: (campaignId) => get(`/campaigns/${campaignId}/steps`),
    updateStep: (campaignId, stepId, data) => put(`/campaigns/${campaignId}/steps/${stepId}`, data),
    enrollContact: (contactId, campaignId) => post(`/contacts/${contactId}/campaign/${campaignId}/enroll`),
    getProgress: (contactId, campaignId) => get(`/contacts/${contactId}/campaigns/${campaignId}/progress`),
  },
};

/**
 * Helper to set tenant ID
 */
export const setTenantId = (tenantId) => {
  localStorage.setItem('tenantId', tenantId);
};

/**
 * Helper to get tenant ID
 */
export const getTenantId = () => {
  return localStorage.getItem('tenantId');
};

export default api;
